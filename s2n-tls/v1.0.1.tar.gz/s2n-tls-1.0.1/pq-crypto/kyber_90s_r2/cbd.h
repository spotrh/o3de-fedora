#ifndef CBD_H
#define CBD_H

#include "poly.h"

void PQCLEAN_KYBER51290S_CLEAN_cbd(poly *r, const uint8_t *buf);

#endif
