from entrypoint2 import entrypoint

# no VERSION


@entrypoint
def f():
    return 7
