from bt import backend_to_check


def test_default():
    backend_to_check(None)
