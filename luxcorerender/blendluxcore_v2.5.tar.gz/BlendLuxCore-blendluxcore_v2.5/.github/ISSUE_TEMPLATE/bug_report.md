---
name: Bug report
about: Create a report to help us improve
title: ''
labels: ''
assignees: ''

---

.blend file: 


Steps to reproduce:


Screenshots or rendered images:


Error message from Blender console:


OS: 
Blender version:
LuxCore version:
