astc_image_info
===============

.. automodule:: astc_image_info
    :members:
    :undoc-members:
    :inherited-members:
    :show-inheritance:
